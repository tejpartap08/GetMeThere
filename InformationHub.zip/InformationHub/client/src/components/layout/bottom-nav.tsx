import { Home, Map, Bus, Bell, MoreHorizontal } from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface NavItem {
  path: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}

const navItems: NavItem[] = [
  { path: "/", icon: Home, label: "Home" },
  { path: "/map", icon: Map, label: "Map" },
  { path: "/routes", icon: Bus, label: "Routes" },
  { path: "/alerts", icon: Bell, label: "Alerts" },
  { path: "/more", icon: MoreHorizontal, label: "More" },
];

export default function BottomNav() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 shadow-lg mobile-safe-area">
      <div className="flex">
        {navItems.map(({ path, icon: Icon, label }) => {
          const isActive = location === path;
          return (
            <Link
              key={path}
              href={path}
              className={cn(
                "flex-1 py-3 px-4 text-center transition-colors",
                isActive 
                  ? "nav-active" 
                  : "text-gray-600 hover:text-primary hover:bg-gray-50"
              )}
            >
              <Icon className="block mx-auto mb-1 h-5 w-5" />
              <span className="text-xs font-medium">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
