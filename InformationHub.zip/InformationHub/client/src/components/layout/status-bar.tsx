export default function StatusBar() {
  const now = new Date();
  const timeString = now.toLocaleTimeString('en-US', { 
    hour: 'numeric', 
    minute: '2-digit',
    hour12: true 
  });

  return (
    <div className="status-bar text-white px-4 py-2 flex justify-between items-center text-sm">
      <span>{timeString}</span>
      <span className="font-medium">GetMeThere</span>
      <div className="flex items-center space-x-1">
        <div className="w-4 h-2 border border-white rounded-sm">
          <div className="w-3 h-1 bg-white rounded-sm m-0.5"></div>
        </div>
        <div className="flex flex-col space-y-0.5">
          <div className="w-1 h-0.5 bg-white"></div>
          <div className="w-1 h-0.5 bg-white"></div>
          <div className="w-1 h-0.5 bg-white"></div>
        </div>
        <div className="w-4 h-2 bg-white rounded-sm"></div>
      </div>
    </div>
  );
}
