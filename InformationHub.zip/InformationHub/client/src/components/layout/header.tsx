import { Search, Bell, User } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

interface HeaderProps {
  location?: string;
  onSearch?: (query: string) => void;
  notificationCount?: number;
}

export default function Header({ 
  location = "Quakers Hill, NSW", 
  onSearch,
  notificationCount = 3 
}: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    if (onSearch && value.length > 2) {
      onSearch(value);
    }
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-4 py-3">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">GetMeThere</h1>
          <p className="text-sm text-gray-600">{location}</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Button variant="ghost" size="icon" className="rounded-full bg-gray-100 hover:bg-gray-200">
              <Bell className="h-5 w-5 text-gray-600" />
            </Button>
            {notificationCount > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
              >
                {notificationCount}
              </Badge>
            )}
          </div>
          <Button variant="ghost" size="icon" className="rounded-full bg-gray-100 hover:bg-gray-200">
            <User className="h-5 w-5 text-gray-600" />
          </Button>
        </div>
      </div>
      
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input 
          type="text" 
          placeholder="Search stops, routes, destinations..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="pl-10 pr-4 py-3 border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent"
        />
      </div>
    </header>
  );
}
