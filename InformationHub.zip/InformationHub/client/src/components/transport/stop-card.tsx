import { MapPin, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { TransportStop, LiveTransport, TransportRoute, RouteInfo } from "@/types/transport";
import RouteCard from "./route-card";

interface StopCardProps {
  stop: TransportStop;
  liveTransports: LiveTransport[];
  routes: TransportRoute[];
  isFavorite?: boolean;
  onToggleFavorite?: (stopId: string) => void;
}

export default function StopCard({ 
  stop, 
  liveTransports, 
  routes, 
  isFavorite = false, 
  onToggleFavorite 
}: StopCardProps) {
  // Filter live transports for this stop
  const stopTransports = liveTransports.filter(transport => transport.stopId === stop.stopId);
  
  // Create route info with live data
  const routeInfos = stop.routes.map(routeId => {
    const route = routes.find(r => r.routeId === routeId);
    const transport = stopTransports.find(t => t.routeId === routeId);
    
    if (!route) return null;
    
    return {
      ...route,
      nextArrival: transport?.estimatedArrival,
      occupancyLevel: transport?.occupancyLevel || 0,
      delay: transport?.delay || 0,
      isDelayed: (transport?.delay || 0) > 2,
    };
  }).filter(Boolean) as RouteInfo[];

  const formatDistance = (distance?: number) => {
    if (!distance) return "";
    return distance < 1 ? `${Math.round(distance * 1000)}m away` : `${distance.toFixed(1)}km away`;
  };

  return (
    <Card className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center">
            <MapPin className="h-5 w-5 text-primary mr-2" />
            <div>
              <h3 className="font-medium text-gray-900">{stop.name}</h3>
              <p className="text-sm text-gray-600">{formatDistance(stop.distance)}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onToggleFavorite?.(stop.stopId)}
            className="p-2 rounded-full bg-gray-100 hover:bg-gray-200"
          >
            <Star className={cn(
              "h-4 w-4",
              isFavorite ? "text-yellow-500 fill-current" : "text-gray-600"
            )} />
          </Button>
        </div>
        
        {/* Route List */}
        <div className="space-y-2">
          {routeInfos.map((routeInfo) => (
            <RouteCard key={routeInfo.routeId} route={routeInfo} />
          ))}
          
          {routeInfos.length === 0 && (
            <div className="text-center py-4 text-gray-500">
              <p className="text-sm">No live transport data available</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
