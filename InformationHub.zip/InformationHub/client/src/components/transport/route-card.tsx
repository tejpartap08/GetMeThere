import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { RouteInfo } from "@/types/transport";

interface RouteCardProps {
  route: RouteInfo;
}

export default function RouteCard({ route }: RouteCardProps) {
  const formatArrivalTime = (arrival?: Date, delay = 0) => {
    if (!arrival) return "No data";
    
    const now = new Date();
    const diffMs = arrival.getTime() - now.getTime();
    const diffMins = Math.round(diffMs / 60000);
    
    if (diffMins <= 0) return "Due now";
    if (delay > 2) return "Delayed";
    
    return `${diffMins} min`;
  };

  const getOccupancyColor = (level: number) => {
    if (level <= 40) return "occupancy-low";
    if (level <= 70) return "occupancy-medium";
    return "occupancy-high";
  };

  const getOccupancyText = (level: number) => {
    if (level <= 40) return `${level}% full`;
    if (level <= 70) return `${level}% full`;
    return `${level}% full`;
  };

  const arrivalText = formatArrivalTime(route.nextArrival, route.delay);
  const isDelayed = route.isDelayed || arrivalText === "Delayed";

  return (
    <div className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-lg">
      <div className="flex items-center">
        <div 
          className="w-8 h-8 rounded-lg flex items-center justify-center mr-3 text-white"
          style={{ backgroundColor: route.color }}
        >
          <span className="text-sm font-bold">{route.routeNumber}</span>
        </div>
        <div>
          <p className="font-medium text-gray-900">{route.name}</p>
          <p className="text-xs text-gray-600">{route.destination}</p>
        </div>
      </div>
      <div className="text-right">
        <p className={cn(
          "font-semibold",
          isDelayed ? "arrival-time-delayed" : "arrival-time-normal"
        )}>
          {arrivalText}
        </p>
        <div className="flex items-center text-xs text-gray-600">
          <div className={cn(
            "w-2 h-2 rounded-full mr-1",
            getOccupancyColor(route.occupancyLevel || 0)
          )}></div>
          <span>{getOccupancyText(route.occupancyLevel || 0)}</span>
        </div>
      </div>
    </div>
  );
}
