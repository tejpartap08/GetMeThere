import { Home, School } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface QuickAccessProps {
  onEditFavorites?: () => void;
}

interface FavoriteRoute {
  id: string;
  name: string;
  route: string;
  nextArrival: string;
  icon: React.ComponentType<{ className?: string }>;
  gradientClass: string;
}

const favoriteRoutes: FavoriteRoute[] = [
  {
    id: "home",
    name: "Home",
    route: "Bus 632",
    nextArrival: "8 min",
    icon: Home,
    gradientClass: "quick-access-home",
  },
  {
    id: "school",
    name: "School",
    route: "Bus 745", 
    nextArrival: "12 min",
    icon: School,
    gradientClass: "quick-access-school",
  },
];

export default function QuickAccess({ onEditFavorites }: QuickAccessProps) {
  return (
    <section className="px-4 py-4">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold text-gray-900">Quick Access</h2>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onEditFavorites}
          className="text-primary hover:text-primary/80"
        >
          Edit
        </Button>
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        {favoriteRoutes.map((route) => {
          const Icon = route.icon;
          return (
            <Card 
              key={route.id}
              className={`${route.gradientClass} p-4 text-white shadow-lg border-none cursor-pointer hover:scale-105 transition-transform`}
            >
              <div className="flex items-center justify-between mb-2">
                <Icon className="h-5 w-5" />
                <Badge variant="secondary" className="bg-white/20 text-white border-none text-xs">
                  {route.route}
                </Badge>
              </div>
              <p className="font-medium">{route.name}</p>
              <p className="text-sm opacity-90">Next in {route.nextArrival}</p>
            </Card>
          );
        })}
      </div>
    </section>
  );
}
