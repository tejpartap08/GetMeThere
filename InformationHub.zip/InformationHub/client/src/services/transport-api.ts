import { apiRequest } from "@/lib/queryClient";
import { TransportStop, TransportRoute, LiveTransport, TripPlan, Alert } from "@/types/transport";

export class TransportAPI {
  static async getAllStops(): Promise<TransportStop[]> {
    const response = await apiRequest("GET", "/api/stops");
    return response.json();
  }

  static async getNearbyStops(latitude: number, longitude: number, radius: number = 5): Promise<TransportStop[]> {
    const response = await apiRequest("GET", `/api/stops/nearby?latitude=${latitude}&longitude=${longitude}&radius=${radius}`);
    return response.json();
  }

  static async getAllRoutes(): Promise<TransportRoute[]> {
    const response = await apiRequest("GET", "/api/routes");
    return response.json();
  }

  static async getLiveTransport(): Promise<LiveTransport[]> {
    const response = await apiRequest("GET", "/api/live-transport");
    return response.json();
  }

  static async getLiveTransportByRoute(routeId: string): Promise<LiveTransport[]> {
    const response = await apiRequest("GET", `/api/live-transport/route/${routeId}`);
    return response.json();
  }

  static async getLiveTransportByStop(stopId: string): Promise<LiveTransport[]> {
    const response = await apiRequest("GET", `/api/live-transport/stop/${stopId}`);
    return response.json();
  }

  static async createTripPlan(tripPlan: Omit<TripPlan, 'id' | 'createdAt'>): Promise<TripPlan> {
    const response = await apiRequest("POST", "/api/trip-plans", tripPlan);
    return response.json();
  }

  static async getAlerts(): Promise<Alert[]> {
    const response = await apiRequest("GET", "/api/alerts");
    return response.json();
  }
}
