export interface TransportStop {
  id: number;
  stopId: string;
  name: string;
  location: string;
  latitude: number;
  longitude: number;
  routes: string[];
  isActive: boolean;
  distance?: number; // calculated distance from user location
}

export interface TransportRoute {
  id: number;
  routeId: string;
  routeNumber: string;
  name: string;
  destination: string;
  color: string;
  isActive: boolean;
}

export interface LiveTransport {
  id: number;
  vehicleId: string;
  routeId: string;
  stopId?: string;
  latitude: number;
  longitude: number;
  heading?: number;
  speed?: number;
  occupancyLevel: number; // 0-100 percentage
  estimatedArrival?: Date;
  delay: number; // in minutes
  lastUpdated: Date;
}

export interface RouteInfo extends TransportRoute {
  nextArrival?: Date;
  occupancyLevel?: number;
  delay?: number;
  isDelayed?: boolean;
}

export interface StopInfo extends Omit<TransportStop, 'routes'> {
  routes: RouteInfo[];
  liveTransports: LiveTransport[];
}

export interface UserLocation {
  latitude: number;
  longitude: number;
  accuracy?: number;
  timestamp?: Date;
}

export interface TripPlan {
  id: number;
  userId?: number;
  fromLocation: string;
  toLocation: string;
  fromLatitude: number;
  fromLongitude: number;
  toLatitude: number;
  toLongitude: number;
  routes?: any;
  estimatedDuration?: number;
  createdAt: Date;
}

export interface Alert {
  id: number;
  routeId?: string;
  stopId?: string;
  title: string;
  message: string;
  severity: 'info' | 'warning' | 'critical';
  isActive: boolean;
  createdAt: Date;
  expiresAt?: Date;
}

export interface WebSocketMessage {
  type: 'initial_data' | 'live_transport_update' | 'subscription_confirmed' | 'subscribe';
  data: any;
  timestamp?: string;
}
