import { Settings, User, Heart, MapPin, Bell, Info, LogOut } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import StatusBar from "@/components/layout/status-bar";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { useToast } from "@/hooks/use-toast";

export default function MorePage() {
  const { toast } = useToast();

  const handleNotificationToggle = (enabled: boolean) => {
    toast({
      title: enabled ? "Notifications Enabled" : "Notifications Disabled",
      description: enabled 
        ? "You'll receive alerts about delays and arrivals" 
        : "You won't receive any notifications",
    });
  };

  const handleFeatureClick = (feature: string) => {
    toast({
      title: `${feature}`,
      description: "This feature will be available soon!",
    });
  };

  return (
    <div className="max-w-md mx-auto bg-white shadow-lg min-h-screen relative">
      <StatusBar />
      <Header location="Settings & More" />

      <main className="pb-20">
        {/* User Profile Section */}
        <section className="px-4 py-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
                  <User className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Student User</h3>
                  <p className="text-sm text-gray-600">Quakers Hill High School</p>
                  <Badge variant="secondary" className="mt-1">
                    Free Account
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Quick Settings */}
        <section className="px-4 py-2">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Quick Settings</h2>
          
          <Card className="mb-3">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Bell className="h-5 w-5 text-gray-600" />
                  <div>
                    <p className="font-medium text-gray-900">Push Notifications</p>
                    <p className="text-sm text-gray-600">Get alerts for delays and arrivals</p>
                  </div>
                </div>
                <Switch 
                  defaultChecked={true}
                  onCheckedChange={handleNotificationToggle}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-gray-600" />
                  <div>
                    <p className="font-medium text-gray-900">Location Services</p>
                    <p className="text-sm text-gray-600">Find nearby stops and routes</p>
                  </div>
                </div>
                <Switch 
                  defaultChecked={true}
                  onCheckedChange={(enabled) => handleNotificationToggle(enabled)}
                />
              </div>
            </CardContent>
          </Card>
        </section>

        {/* App Features */}
        <section className="px-4 py-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">App Features</h2>
          
          <div className="space-y-3">
            <Card>
              <CardContent className="p-4">
                <Button
                  variant="ghost"
                  className="w-full justify-start p-0 h-auto"
                  onClick={() => handleFeatureClick("Favorite Routes")}
                >
                  <div className="flex items-center space-x-3">
                    <Heart className="h-5 w-5 text-gray-600" />
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Favorite Routes</p>
                      <p className="text-sm text-gray-600">Manage your saved routes and stops</p>
                    </div>
                  </div>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <Button
                  variant="ghost"
                  className="w-full justify-start p-0 h-auto"
                  onClick={() => handleFeatureClick("Trip History")}
                >
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-gray-600" />
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Trip History</p>
                      <p className="text-sm text-gray-600">View your recent journeys</p>
                    </div>
                  </div>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <Button
                  variant="ghost"
                  className="w-full justify-start p-0 h-auto"
                  onClick={() => handleFeatureClick("Offline Maps")}
                >
                  <div className="flex items-center space-x-3">
                    <Settings className="h-5 w-5 text-gray-600" />
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Offline Maps</p>
                      <p className="text-sm text-gray-600">Download routes for offline use</p>
                    </div>
                  </div>
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* App Information */}
        <section className="px-4 py-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">App Information</h2>
          
          <div className="space-y-3">
            <Card>
              <CardContent className="p-4">
                <Button
                  variant="ghost"
                  className="w-full justify-start p-0 h-auto"
                  onClick={() => handleFeatureClick("About GetMeThere")}
                >
                  <div className="flex items-center space-x-3">
                    <Info className="h-5 w-5 text-gray-600" />
                    <div className="text-left">
                      <p className="font-medium text-gray-900">About GetMeThere</p>
                      <p className="text-sm text-gray-600">Version 1.0.0 - Built for students</p>
                    </div>
                  </div>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <Button
                  variant="ghost"
                  className="w-full justify-start p-0 h-auto"
                  onClick={() => handleFeatureClick("Privacy Policy")}
                >
                  <div className="flex items-center space-x-3">
                    <Settings className="h-5 w-5 text-gray-600" />
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Privacy Policy</p>
                      <p className="text-sm text-gray-600">How we protect your data</p>
                    </div>
                  </div>
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Account Actions */}
        <section className="px-4 py-4">
          <Card>
            <CardContent className="p-4">
              <Button
                variant="ghost"
                className="w-full justify-start p-0 h-auto text-red-600 hover:text-red-700"
                onClick={() => handleFeatureClick("Sign Out")}
              >
                <div className="flex items-center space-x-3">
                  <LogOut className="h-5 w-5" />
                  <p className="font-medium">Sign Out</p>
                </div>
              </Button>
            </CardContent>
          </Card>
        </section>

        {/* App Stats */}
        <section className="px-4 py-2">
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold text-gray-900 mb-3">Your Stats This Week</h3>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-primary">12</div>
                  <div className="text-xs text-gray-600">Trips Taken</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600">3.5h</div>
                  <div className="text-xs text-gray-600">Time Saved</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-orange-600">5</div>
                  <div className="text-xs text-gray-600">Routes Used</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>

      <BottomNav />
    </div>
  );
}
