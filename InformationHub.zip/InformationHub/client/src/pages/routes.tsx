import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bus, Clock, MapPin, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import StatusBar from "@/components/layout/status-bar";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { TransportAPI } from "@/services/transport-api";
import { useWebSocket } from "@/hooks/use-websocket";
import { TransportRoute } from "@/types/transport";

export default function RoutesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [favoriteRoutes, setFavoriteRoutes] = useState<string[]>([]);
  const { liveTransports } = useWebSocket();

  const { data: routes = [], isLoading } = useQuery<TransportRoute[]>({
    queryKey: ["/api/routes"],
  });

  const filteredRoutes = routes.filter(route =>
    route.routeNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    route.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    route.destination.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleFavorite = (routeId: string) => {
    setFavoriteRoutes(prev =>
      prev.includes(routeId)
        ? prev.filter(id => id !== routeId)
        : [...prev, routeId]
    );
  };

  const getRouteStats = (routeId: string) => {
    const routeTransports = liveTransports.filter(t => t.routeId === routeId);
    const averageDelay = routeTransports.length > 0
      ? routeTransports.reduce((sum, t) => sum + t.delay, 0) / routeTransports.length
      : 0;
    const averageOccupancy = routeTransports.length > 0
      ? routeTransports.reduce((sum, t) => sum + t.occupancyLevel, 0) / routeTransports.length
      : 0;

    return {
      activeBuses: routeTransports.length,
      averageDelay: Math.round(averageDelay),
      averageOccupancy: Math.round(averageOccupancy),
    };
  };

  return (
    <div className="max-w-md mx-auto bg-white shadow-lg min-h-screen relative">
      <StatusBar />
      <Header location="All Routes" />

      <main className="pb-20">
        {/* Search Section */}
        <section className="px-4 py-4">
          <div className="relative">
            <Bus className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="Search routes by number or destination..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-3 border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>
        </section>

        {/* Routes List */}
        <section className="px-4">
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                        <div>
                          <div className="h-4 bg-gray-200 rounded w-24 mb-2"></div>
                          <div className="h-3 bg-gray-200 rounded w-32"></div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredRoutes.length > 0 ? (
            <div className="space-y-3">
              {filteredRoutes.map(route => {
                const stats = getRouteStats(route.routeId);
                const isFavorite = favoriteRoutes.includes(route.routeId);
                
                return (
                  <Card key={route.routeId} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex items-center space-x-3">
                          <div 
                            className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold"
                            style={{ backgroundColor: route.color }}
                          >
                            {route.routeNumber}
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{route.name}</h3>
                            <p className="text-sm text-gray-600">{route.destination}</p>
                          </div>
                        </div>
                        
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggleFavorite(route.routeId)}
                          className="text-gray-400 hover:text-yellow-500"
                        >
                          <Star className={isFavorite ? "fill-current text-yellow-500" : "text-gray-400"} />
                        </Button>
                      </div>

                      {/* Route Statistics */}
                      <div className="grid grid-cols-3 gap-2 mb-3">
                        <div className="text-center">
                          <div className="flex items-center justify-center space-x-1">
                            <Bus className="h-3 w-3 text-green-600" />
                            <span className="text-sm font-medium text-green-600">
                              {stats.activeBuses}
                            </span>
                          </div>
                          <span className="text-xs text-gray-500">Active</span>
                        </div>
                        
                        <div className="text-center">
                          <div className="flex items-center justify-center space-x-1">
                            <Clock className="h-3 w-3 text-orange-600" />
                            <span className={`text-sm font-medium ${stats.averageDelay > 2 ? 'text-red-600' : 'text-green-600'}`}>
                              {stats.averageDelay > 0 ? `+${stats.averageDelay}m` : 'On time'}
                            </span>
                          </div>
                          <span className="text-xs text-gray-500">Delay</span>
                        </div>
                        
                        <div className="text-center">
                          <div className="flex items-center justify-center space-x-1">
                            <div className={`w-3 h-3 rounded-full ${
                              stats.averageOccupancy <= 40 ? 'bg-green-400' :
                              stats.averageOccupancy <= 70 ? 'bg-orange-400' : 'bg-red-400'
                            }`}></div>
                            <span className="text-sm font-medium text-gray-700">
                              {stats.averageOccupancy}%
                            </span>
                          </div>
                          <span className="text-xs text-gray-500">Full</span>
                        </div>
                      </div>

                      {/* Route Status */}
                      <div className="flex items-center justify-between">
                        <div className="flex space-x-2">
                          {stats.activeBuses > 0 ? (
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              Live tracking
                            </Badge>
                          ) : (
                            <Badge variant="secondary" className="bg-gray-100 text-gray-600">
                              No live data
                            </Badge>
                          )}
                          
                          {stats.averageDelay > 5 && (
                            <Badge variant="destructive" className="bg-red-100 text-red-800">
                              Delays
                            </Badge>
                          )}
                        </div>
                        
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
                          <MapPin className="h-4 w-4 mr-1" />
                          View Route
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="p-6 text-center">
                <Bus className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-500">
                  {searchQuery ? `No routes found for "${searchQuery}"` : "No routes available"}
                </p>
                {searchQuery && (
                  <Button 
                    variant="ghost" 
                    onClick={() => setSearchQuery("")}
                    className="mt-2 text-primary"
                  >
                    Clear search
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </section>
      </main>

      <BottomNav />
    </div>
  );
}
