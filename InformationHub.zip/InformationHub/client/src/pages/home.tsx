import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowDownRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import StatusBar from "@/components/layout/status-bar";
import Header from "@/components/layout/header";
import QuickAccess from "@/components/transport/quick-access";
import StopCard from "@/components/transport/stop-card";
import BottomNav from "@/components/layout/bottom-nav";
import { TransportAPI } from "@/services/transport-api";
import { useWebSocket } from "@/hooks/use-websocket";
import { useLocation } from "@/hooks/use-location";
import { useToast } from "@/hooks/use-toast";
import { TransportStop, TransportRoute } from "@/types/transport";

export default function Home() {
  const [tripFrom, setTripFrom] = useState("Quakers Hill Station");
  const [tripTo, setTripTo] = useState("");
  const [favoriteStops, setFavoriteStops] = useState<string[]>([]);
  const { toast } = useToast();
  const { location, error: locationError } = useLocation();
  const { liveTransports, isConnected, lastUpdate } = useWebSocket();

  // Fetch nearby stops
  const { data: nearbyStops = [], isLoading: stopsLoading } = useQuery<TransportStop[]>({
    queryKey: ["/api/stops/nearby", location?.latitude, location?.longitude],
    enabled: !!location,
  });

  // Fetch all routes for route info
  const { data: routes = [] } = useQuery<TransportRoute[]>({
    queryKey: ["/api/routes"],
  });

  const handleSearch = (query: string) => {
    console.log("Searching for:", query);
    toast({
      title: "Search",
      description: `Searching for "${query}"...`,
    });
  };

  const handlePlanTrip = async () => {
    if (!tripFrom || !tripTo) {
      toast({
        title: "Missing Information",
        description: "Please enter both departure and destination locations",
        variant: "destructive",
      });
      return;
    }

    if (!location) {
      toast({
        title: "Location Required",
        description: "Please enable location services to plan your trip",
        variant: "destructive",
      });
      return;
    }

    try {
      // TODO: Implement actual route planning
      toast({
        title: "Planning Route",
        description: "Finding the best routes for your trip...",
      });
      
      // Simulate route planning delay
      setTimeout(() => {
        toast({
          title: "Route Found!",
          description: "Check the Routes tab to see your planned journey",
        });
      }, 2000);
    } catch (error) {
      toast({
        title: "Planning Failed",
        description: "Unable to plan route. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleToggleFavorite = (stopId: string) => {
    setFavoriteStops(prev => 
      prev.includes(stopId) 
        ? prev.filter(id => id !== stopId)
        : [...prev, stopId]
    );
  };

  const handleSwapLocations = () => {
    const temp = tripFrom;
    setTripFrom(tripTo);
    setTripTo(temp);
  };

  const handleQuickPlan = () => {
    // TODO: Implement quick route planning modal
    toast({
      title: "Quick Plan",
      description: "Quick route planning feature coming soon!",
    });
  };

  useEffect(() => {
    if (locationError) {
      toast({
        title: "Location Error",
        description: locationError,
        variant: "destructive",
      });
    }
  }, [locationError, toast]);

  return (
    <div className="max-w-md mx-auto bg-white shadow-lg min-h-screen relative">
      <StatusBar />
      <Header 
        location={location ? "Quakers Hill, NSW" : "Location unavailable"}
        onSearch={handleSearch}
        notificationCount={3}
      />

      <main className="pb-20">
        <QuickAccess onEditFavorites={() => toast({ title: "Edit Favorites", description: "Feature coming soon!" })} />

        {/* Nearby Stops Section */}
        <section className="px-4 py-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Nearby Stops</h2>
            <div className="flex items-center text-sm text-gray-600">
              <div className={`w-2 h-2 rounded-full mr-2 ${isConnected ? 'bg-green-500 pulse-dot' : 'bg-gray-400'}`}></div>
              <span>{isConnected ? 'Live' : 'Offline'}</span>
            </div>
          </div>

          {stopsLoading ? (
            <div className="space-y-3">
              {[1, 2].map(i => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-4">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
                    <div className="space-y-2">
                      <div className="h-12 bg-gray-100 rounded"></div>
                      <div className="h-12 bg-gray-100 rounded"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : nearbyStops.length > 0 ? (
            <div className="space-y-3">
              {nearbyStops.map((stop: TransportStop) => (
                <StopCard
                  key={stop.stopId}
                  stop={stop}
                  liveTransports={liveTransports}
                  routes={routes}
                  isFavorite={favoriteStops.includes(stop.stopId)}
                  onToggleFavorite={handleToggleFavorite}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-gray-500">No nearby stops found</p>
                <p className="text-sm text-gray-400 mt-1">
                  {location ? "Try enabling location services" : "Please allow location access in your browser"}
                </p>
                {!location && (
                  <Button 
                    onClick={() => window.location.reload()} 
                    className="mt-3"
                    size="sm"
                  >
                    Refresh & Allow Location
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </section>

        {/* Live Map Section */}
        <section className="px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-gray-900">Live Map</h2>
            <Button variant="ghost" className="text-primary hover:text-primary/80">
              View Full
            </Button>
          </div>
          
          <div className="relative bg-gray-200 rounded-xl overflow-hidden h-48 bg-gradient-to-br from-blue-100 to-green-100">
            <div className="transport-map-overlay absolute inset-0 bg-opacity-60 flex items-center justify-center">
              <div className="text-center text-white">
                <div className="w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M12 1.586l-4 4v12.828l4-4V1.586zM3.707 3.293A1 1 0 004 4v10a1 1 0 00.293.707L6 16.414V5.586L3.707 3.293zM17.707 3.293L16 1.586v10.828l1.707 1.707A1 1 0 0018 14V4a1 1 0 00-.293-.707z" clipRule="evenodd" />
                  </svg>
                </div>
                <p className="text-sm">Tap to view live transport positions</p>
              </div>
            </div>
            
            <div className="absolute top-4 left-4 bg-white rounded-lg px-3 py-2 shadow-lg">
              <div className="flex items-center text-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                <span className="font-medium">{liveTransports.length} buses tracked</span>
              </div>
            </div>
          </div>
        </section>

        {/* Trip Planner Section */}
        <section className="px-4 py-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Plan Your Trip</h2>
          
          <Card>
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="relative">
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2 w-3 h-3 bg-green-600 rounded-full"></div>
                  <Input 
                    type="text" 
                    placeholder="From: Current Location"
                    value={tripFrom}
                    onChange={(e) => setTripFrom(e.target.value)}
                    className="pl-10 pr-4 py-3 border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                </div>
                
                <div className="relative">
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2 w-3 h-3 bg-red-600 rounded-full"></div>
                  <Input 
                    type="text" 
                    placeholder="To: Enter destination"
                    value={tripTo}
                    onChange={(e) => setTripTo(e.target.value)}
                    className="pl-10 pr-4 py-3 border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                </div>
                
                <div className="flex space-x-3">
                  <Button 
                    onClick={handlePlanTrip}
                    className="flex-1 bg-primary hover:bg-primary/90 py-3 px-4 rounded-lg font-medium"
                  >
                    Plan Route
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={handleSwapLocations}
                    className="p-3 border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                    </svg>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>

      <BottomNav />

      {/* Floating Action Button */}
      <Button
        onClick={handleQuickPlan}
        className="fixed bottom-24 right-4 w-14 h-14 bg-primary hover:bg-primary/90 text-white rounded-full shadow-lg flex items-center justify-center hover:scale-105 transition-all"
      >
        <ArrowDownRight className="h-6 w-6" />
      </Button>
    </div>
  );
}
