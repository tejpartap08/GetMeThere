import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, Info, XCircle, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import StatusBar from "@/components/layout/status-bar";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { TransportAPI } from "@/services/transport-api";
import { Alert } from "@/types/transport";
import { cn } from "@/lib/utils";

export default function AlertsPage() {
  const { data: alerts = [], isLoading } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
  });

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <XCircle className="h-5 w-5" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5" />;
      case 'info':
      default:
        return <Info className="h-5 w-5" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'warning':
        return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'info':
      default:
        return 'text-blue-600 bg-blue-50 border-blue-200';
    }
  };

  const getBadgeVariant = (severity: string): "default" | "secondary" | "destructive" => {
    switch (severity) {
      case 'critical':
        return 'destructive';
      case 'warning':
        return 'default';
      case 'info':
      default:
        return 'secondary';
    }
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 60) {
      return `${diffMins}m ago`;
    } else if (diffHours < 24) {
      return `${diffHours}h ago`;
    } else {
      return `${diffDays}d ago`;
    }
  };

  const groupedAlerts = alerts.reduce((groups, alert) => {
    if (!groups[alert.severity]) {
      groups[alert.severity] = [];
    }
    groups[alert.severity].push(alert);
    return groups;
  }, {} as Record<string, Alert[]>);

  // Order by severity: critical, warning, info
  const severityOrder = ['critical', 'warning', 'info'];
  const orderedSeverities = severityOrder.filter(severity => groupedAlerts[severity]?.length > 0);

  return (
    <div className="max-w-md mx-auto bg-white shadow-lg min-h-screen relative">
      <StatusBar />
      <Header location="Transport Alerts" notificationCount={alerts.length} />

      <main className="pb-20">
        {/* Alert Summary */}
        <section className="px-4 py-4">
          <div className="grid grid-cols-3 gap-3 mb-4">
            <Card>
              <CardContent className="p-3 text-center">
                <div className="text-xl font-bold text-red-600">
                  {groupedAlerts.critical?.length || 0}
                </div>
                <div className="text-xs text-gray-600">Critical</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3 text-center">
                <div className="text-xl font-bold text-orange-600">
                  {groupedAlerts.warning?.length || 0}
                </div>
                <div className="text-xs text-gray-600">Warnings</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3 text-center">
                <div className="text-xl font-bold text-blue-600">
                  {groupedAlerts.info?.length || 0}
                </div>
                <div className="text-xs text-gray-600">Info</div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Alerts List */}
        <section className="px-4">
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-5 h-5 bg-gray-200 rounded"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : orderedSeverities.length > 0 ? (
            <div className="space-y-4">
              {orderedSeverities.map(severity => (
                <div key={severity}>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 capitalize">
                    {severity} Alerts ({groupedAlerts[severity].length})
                  </h3>
                  
                  <div className="space-y-3">
                    {groupedAlerts[severity].map(alert => (
                      <Card key={alert.id} className={cn("border-l-4", getSeverityColor(alert.severity))}>
                        <CardContent className="p-4">
                          <div className="flex items-start space-x-3">
                            <div className={cn("flex-shrink-0", getSeverityColor(alert.severity))}>
                              {getSeverityIcon(alert.severity)}
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between mb-2">
                                <h4 className="font-semibold text-gray-900 text-sm">
                                  {alert.title}
                                </h4>
                                <div className="flex items-center space-x-2 ml-2">
                                  <Badge variant={getBadgeVariant(alert.severity)} className="text-xs">
                                    {alert.severity.toUpperCase()}
                                  </Badge>
                                </div>
                              </div>
                              
                              <p className="text-sm text-gray-600 mb-3">
                                {alert.message}
                              </p>
                              
                              <div className="flex items-center justify-between text-xs text-gray-500">
                                <div className="flex items-center space-x-4">
                                  {alert.routeId && (
                                    <span className="flex items-center">
                                      <Clock className="h-3 w-3 mr-1" />
                                      Route {alert.routeId}
                                    </span>
                                  )}
                                  
                                  {alert.stopId && (
                                    <span>Stop: {alert.stopId}</span>
                                  )}
                                </div>
                                
                                <span>{formatDate(alert.createdAt)}</span>
                              </div>
                              
                              {alert.expiresAt && (
                                <div className="mt-2 text-xs text-gray-500">
                                  Expires: {alert.expiresAt.toLocaleDateString()} at {alert.expiresAt.toLocaleTimeString()}
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-6 text-center">
                <Info className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Active Alerts</h3>
                <p className="text-gray-500">
                  All transport services are running normally
                </p>
              </CardContent>
            </Card>
          )}
        </section>
      </main>

      <BottomNav />
    </div>
  );
}
