import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { MapPin, Navigation, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import StatusBar from "@/components/layout/status-bar";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { useWebSocket } from "@/hooks/use-websocket";
import { useLocation } from "@/hooks/use-location";
import { TransportAPI } from "@/services/transport-api";
import { TransportStop, TransportRoute } from "@/types/transport";

export default function MapPage() {
  const [mapView, setMapView] = useState<"satellite" | "traffic" | "standard">("standard");
  const { location } = useLocation();
  const { liveTransports, isConnected } = useWebSocket();

  const { data: nearbyStops = [] } = useQuery<TransportStop[]>({
    queryKey: ["/api/stops/nearby", location?.latitude, location?.longitude],
    enabled: !!location,
  });

  const { data: routes = [] } = useQuery<TransportRoute[]>({
    queryKey: ["/api/routes"],
  });

  return (
    <div className="max-w-md mx-auto bg-white shadow-lg min-h-screen relative">
      <StatusBar />
      <Header location="Map View" />

      <main className="pb-20 relative">
        {/* Map Container */}
        <div className="relative h-[70vh] bg-gradient-to-br from-blue-50 to-green-50">
          {/* Map Placeholder */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-gray-600">
              <MapPin className="h-16 w-16 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-semibold mb-2">Interactive Map</h3>
              <p className="text-sm">Live transport positions and routes</p>
            </div>
          </div>

          {/* Map Controls */}
          <div className="absolute top-4 right-4 space-y-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                console.log("Current location button clicked");
                alert("Current location feature clicked! (Demo mode)");
              }}
              className="bg-white shadow-md"
            >
              <Navigation className="h-4 w-4" />
            </Button>
            
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                const views = ["standard", "satellite", "traffic"] as const;
                const currentIndex = views.indexOf(mapView);
                const nextView = views[(currentIndex + 1) % views.length];
                setMapView(nextView);
              }}
              className="bg-white shadow-md"
            >
              <Layers className="h-4 w-4" />
            </Button>
          </div>

          {/* Live Status */}
          <div className="absolute top-4 left-4 bg-white rounded-lg px-3 py-2 shadow-lg">
            <div className="flex items-center text-sm">
              <div className={`w-2 h-2 rounded-full mr-2 ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
              <span className="font-medium">
                {isConnected ? `${liveTransports.length} buses live` : 'Connecting...'}
              </span>
            </div>
          </div>

          {/* Map Mode Indicator */}
          <div className="absolute bottom-4 left-4 bg-white rounded-lg px-3 py-1 shadow-lg">
            <span className="text-sm font-medium capitalize">{mapView} View</span>
          </div>
        </div>

        {/* Map Legend */}
        <section className="px-4 py-4">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Map Legend</h3>
          <div className="grid grid-cols-2 gap-3">
            <Card>
              <CardContent className="p-3">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-primary rounded-full"></div>
                  <span className="text-sm">Bus Stops</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm">Live Buses</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-2 bg-blue-500 rounded"></div>
                  <span className="text-sm">Bus Routes</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                  <span className="text-sm">You Are Here</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Quick Stats */}
        <section className="px-4 py-2">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Live Statistics</h3>
          <div className="grid grid-cols-3 gap-3">
            <Card>
              <CardContent className="p-3 text-center">
                <div className="text-2xl font-bold text-primary">{nearbyStops.length}</div>
                <div className="text-xs text-gray-600">Nearby Stops</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3 text-center">
                <div className="text-2xl font-bold text-green-600">{liveTransports.length}</div>
                <div className="text-xs text-gray-600">Live Buses</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3 text-center">
                <div className="text-2xl font-bold text-orange-600">{routes.length}</div>
                <div className="text-xs text-gray-600">Active Routes</div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <BottomNav />
    </div>
  );
}
