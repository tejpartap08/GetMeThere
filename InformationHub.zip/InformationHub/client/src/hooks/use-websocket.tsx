import { useEffect, useRef, useState } from "react";
import { WebSocketMessage, LiveTransport } from "@/types/transport";

export function useWebSocket() {
  const [isConnected, setIsConnected] = useState(false);
  const [liveTransports, setLiveTransports] = useState<LiveTransport[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date>();
  const websocketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  const connect = () => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    try {
      websocketRef.current = new WebSocket(wsUrl);
      
      websocketRef.current.onopen = () => {
        setIsConnected(true);
        console.log("Connected to GetMeThere WebSocket");
        
        // Subscribe to live transport updates
        websocketRef.current?.send(JSON.stringify({
          type: 'subscribe',
          payload: { topic: 'live_transport' }
        }));
      };

      websocketRef.current.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          
          switch (message.type) {
            case 'live_transport_update':
              setLiveTransports(message.data);
              setLastUpdate(new Date(message.timestamp || Date.now()));
              break;
            case 'initial_data':
              console.log("WebSocket initial data:", message.data);
              break;
            case 'subscription_confirmed':
              console.log("Subscription confirmed:", message.data);
              break;
          }
        } catch (error) {
          console.error("Error parsing WebSocket message:", error);
        }
      };

      websocketRef.current.onclose = (event) => {
        setIsConnected(false);
        console.log("WebSocket connection closed:", event.code, event.reason);
        
        // Attempt to reconnect after 3 seconds
        if (!event.wasClean) {
          reconnectTimeoutRef.current = setTimeout(() => {
            console.log("Attempting to reconnect WebSocket...");
            connect();
          }, 3000);
        }
      };

      websocketRef.current.onerror = (error) => {
        console.error("WebSocket error:", error);
        setIsConnected(false);
      };
    } catch (error) {
      console.error("Failed to create WebSocket connection:", error);
      setIsConnected(false);
    }
  };

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (websocketRef.current) {
        websocketRef.current.close();
      }
    };
  }, []);

  const sendMessage = (message: WebSocketMessage) => {
    if (websocketRef.current && websocketRef.current.readyState === WebSocket.OPEN) {
      websocketRef.current.send(JSON.stringify(message));
    }
  };

  return {
    isConnected,
    liveTransports,
    lastUpdate,
    sendMessage,
    reconnect: connect,
  };
}
