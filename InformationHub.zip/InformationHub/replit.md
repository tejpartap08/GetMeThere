# replit.md

## Overview

This is a full-stack transportation tracking application called "GetMeThere" built with React on the frontend and Express on the backend. The app provides real-time public transport information including stop locations, route tracking, live vehicle positions, trip planning, and service alerts.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with a clear separation between frontend and backend:

### Frontend Architecture
- **React 18** with TypeScript for type safety
- **Vite** as the build tool and development server
- **Wouter** for client-side routing (lightweight alternative to React Router)
- **TanStack Query** for server state management and data fetching
- **Tailwind CSS** with shadcn/ui components for styling
- **Mobile-first responsive design** with a focus on mobile transport users

### Backend Architecture
- **Express.js** server with TypeScript
- **RESTful API** design for transport data endpoints
- **WebSocket server** for real-time transport updates
- **PostgreSQL database** with Drizzle ORM for persistent data storage

### Database Strategy
- **Drizzle ORM** configured for PostgreSQL
- **Schema-first approach** with TypeScript types generated from database schema
- **PostgreSQL** database with persistent storage
- **DatabaseStorage** class implementing all storage operations with PostgreSQL

## Key Components

### Data Models
- **Users**: Authentication and preferences (favorite stops/routes)
- **Transport Stops**: Physical bus/train stop locations with GPS coordinates
- **Transport Routes**: Route definitions with numbers, names, and colors
- **Live Transport**: Real-time vehicle positions, delays, and occupancy
- **Trip Plans**: User-generated journey plans
- **Alerts**: Service disruptions and notifications

### API Endpoints
- `GET /api/stops` - All transport stops
- `GET /api/stops/nearby` - Location-based stop search
- `GET /api/routes` - All transport routes
- `GET /api/live-transport` - Real-time vehicle data
- `POST /api/trip-plans` - Create trip plans
- `GET /api/alerts` - Service alerts

### Real-time Features
- **WebSocket connection** for live transport updates
- **Geolocation integration** for nearby stops
- **Live vehicle tracking** with position and delay information
- **Push notifications** for service alerts

### UI Components
- **Mobile-optimized interface** with bottom navigation
- **Interactive maps** for transport visualization
- **Real-time status indicators** for vehicles and delays
- **Quick access shortcuts** to favorite routes
- **Accessibility features** following WCAG guidelines

## Data Flow

1. **Client Request**: React components request data via TanStack Query
2. **API Layer**: Express routes handle HTTP requests and WebSocket connections
3. **Storage Layer**: Currently in-memory, designed for PostgreSQL migration
4. **Real-time Updates**: WebSocket broadcasts live transport data to connected clients
5. **State Management**: TanStack Query manages server state, React hooks for local state

## External Dependencies

### Core Framework Dependencies
- **React ecosystem**: React 18, TypeScript, Vite
- **UI Components**: Radix UI primitives with shadcn/ui styling
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: TanStack Query for server state

### Backend Dependencies
- **Express.js** with TypeScript support
- **WebSocket (ws)** for real-time communication
- **Drizzle ORM** with PostgreSQL dialect
- **Neon Database** serverless PostgreSQL

### Development Tools
- **ESBuild** for production server bundling
- **PostCSS** with Autoprefixer
- **Replit-specific plugins** for development environment

### Transport APIs (Future Integration)
- GTFS (General Transit Feed Specification) data
- Real-time transport APIs (GTFS-Realtime)
- Mapping services for route visualization

## Deployment Strategy

### Development Environment
- **Vite dev server** for frontend with HMR
- **TSX** for running TypeScript server files
- **Replit integration** with cartographer and error overlay plugins

### Production Build
- **Vite build** for frontend assets to `dist/public`
- **ESBuild bundle** for server to `dist/index.js`
- **Single process deployment** serving both API and static files

### Database Migration Path
1. **Completed**: Successfully migrated from in-memory storage to PostgreSQL
2. **Current**: Drizzle ORM with PostgreSQL database
3. **Features**: Persistent data storage, seeded with sample transport data
4. **Migration**: Database push commands configured (`db:push`)

### Environment Configuration
- **NODE_ENV** for environment switching
- **DATABASE_URL** for PostgreSQL connection
- **Development/Production** mode handling in Vite and Express

The application is designed to be scalable from a simple transport tracker to a comprehensive public transit platform with real-time features and mobile-first user experience.