import { 
  users, transportStops, transportRoutes, liveTransport, tripPlans, alerts,
  type User, type InsertUser,
  type TransportStop, type InsertTransportStop,
  type TransportRoute, type InsertTransportRoute,
  type LiveTransport, type InsertLiveTransport,
  type TripPlan, type InsertTripPlan,
  type Alert, type InsertAlert
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserFavorites(userId: number, favoriteStops: string[], favoriteRoutes: string[]): Promise<User | undefined>;

  // Transport stops
  getAllStops(): Promise<TransportStop[]>;
  getStop(stopId: string): Promise<TransportStop | undefined>;
  getNearbyStops(latitude: number, longitude: number, radiusKm: number): Promise<TransportStop[]>;
  createStop(stop: InsertTransportStop): Promise<TransportStop>;

  // Transport routes
  getAllRoutes(): Promise<TransportRoute[]>;
  getRoute(routeId: string): Promise<TransportRoute | undefined>;
  createRoute(route: InsertTransportRoute): Promise<TransportRoute>;

  // Live transport data
  getLiveTransport(): Promise<LiveTransport[]>;
  getLiveTransportByRoute(routeId: string): Promise<LiveTransport[]>;
  getLiveTransportByStop(stopId: string): Promise<LiveTransport[]>;
  updateLiveTransport(transport: InsertLiveTransport): Promise<LiveTransport>;

  // Trip planning
  createTripPlan(tripPlan: InsertTripPlan): Promise<TripPlan>;
  getUserTripPlans(userId: number): Promise<TripPlan[]>;

  // Alerts
  getActiveAlerts(): Promise<Alert[]>;
  getAlertsByRoute(routeId: string): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private stops: Map<string, TransportStop> = new Map();
  private routes: Map<string, TransportRoute> = new Map();
  private liveTransports: Map<string, LiveTransport> = new Map();
  private tripPlans: Map<number, TripPlan> = new Map();
  private alerts: Map<number, Alert> = new Map();
  private currentUserId = 1;
  private currentStopId = 1;
  private currentRouteId = 1;
  private currentLiveId = 1;
  private currentTripId = 1;
  private currentAlertId = 1;

  constructor() {
    this.initializeTestData();
  }

  private initializeTestData() {
    // Create sample stops
    const stop1: TransportStop = {
      id: this.currentStopId++,
      stopId: "QH_STATION",
      name: "Quakers Hill Station",
      location: "Quakers Hill, NSW",
      latitude: -33.7275,
      longitude: 150.9079,
      routes: ["632", "745"],
      isActive: true,
    };
    
    const stop2: TransportStop = {
      id: this.currentStopId++,
      stopId: "DOUGLAS_RD",
      name: "Douglas Road",
      location: "Quakers Hill, NSW",
      latitude: -33.7285,
      longitude: 150.9069,
      routes: ["623"],
      isActive: true,
    };

    this.stops.set(stop1.stopId, stop1);
    this.stops.set(stop2.stopId, stop2);

    // Create sample routes
    const route1: TransportRoute = {
      id: this.currentRouteId++,
      routeId: "632",
      routeNumber: "632",
      name: "Blacktown",
      destination: "Blacktown via Quakers Hill",
      color: "#2196F3",
      isActive: true,
    };

    const route2: TransportRoute = {
      id: this.currentRouteId++,
      routeId: "745",
      routeNumber: "745",
      name: "Castle Hill",
      destination: "Castle Hill Express",
      color: "#009688",
      isActive: true,
    };

    const route3: TransportRoute = {
      id: this.currentRouteId++,
      routeId: "623",
      routeNumber: "623",
      name: "Parramatta",
      destination: "Parramatta via Blacktown",
      color: "#FF9800",
      isActive: true,
    };

    this.routes.set(route1.routeId, route1);
    this.routes.set(route2.routeId, route2);
    this.routes.set(route3.routeId, route3);

    // Create sample live transport data
    const liveTransport1: LiveTransport = {
      id: this.currentLiveId++,
      vehicleId: "BUS_632_001",
      routeId: "632",
      stopId: "QH_STATION",
      latitude: -33.7270,
      longitude: 150.9075,
      heading: 45,
      speed: 25,
      occupancyLevel: 60,
      estimatedArrival: new Date(Date.now() + 8 * 60000), // 8 minutes from now
      delay: 0,
      lastUpdated: new Date(),
    };

    const liveTransport2: LiveTransport = {
      id: this.currentLiveId++,
      vehicleId: "BUS_745_001",
      routeId: "745",
      stopId: "QH_STATION",
      latitude: -33.7280,
      longitude: 150.9085,
      heading: 90,
      speed: 30,
      occupancyLevel: 30,
      estimatedArrival: new Date(Date.now() + 12 * 60000), // 12 minutes from now
      delay: 0,
      lastUpdated: new Date(),
    };

    const liveTransport3: LiveTransport = {
      id: this.currentLiveId++,
      vehicleId: "BUS_623_001",
      routeId: "623",
      stopId: "DOUGLAS_RD",
      latitude: -33.7290,
      longitude: 150.9065,
      heading: 180,
      speed: 15,
      occupancyLevel: 85,
      estimatedArrival: new Date(Date.now() + 5 * 60000), // 5 minutes from now but delayed
      delay: 3,
      lastUpdated: new Date(),
    };

    this.liveTransports.set(liveTransport1.vehicleId, liveTransport1);
    this.liveTransports.set(liveTransport2.vehicleId, liveTransport2);
    this.liveTransports.set(liveTransport3.vehicleId, liveTransport3);

    // Create sample alerts
    const alert1: Alert = {
      id: this.currentAlertId++,
      routeId: "632",
      stopId: null,
      title: "Service Delay",
      message: "Route 632 buses are running 5-10 minutes late due to heavy traffic on Douglas Road.",
      severity: "warning",
      isActive: true,
      createdAt: new Date(Date.now() - 30 * 60000), // 30 minutes ago
      expiresAt: new Date(Date.now() + 60 * 60000), // expires in 1 hour
    };

    const alert2: Alert = {
      id: this.currentAlertId++,
      routeId: null,
      stopId: "QH_STATION",
      title: "Stop Maintenance",
      message: "Quakers Hill Station bus stop will have reduced accessibility due to maintenance work this afternoon.",
      severity: "info",
      isActive: true,
      createdAt: new Date(Date.now() - 60 * 60000), // 1 hour ago
      expiresAt: new Date(Date.now() + 4 * 60 * 60000), // expires in 4 hours
    };

    const alert3: Alert = {
      id: this.currentAlertId++,
      routeId: "745",
      stopId: null,
      title: "Express Service Cancelled",
      message: "Due to mechanical issues, the next two Express 745 services have been cancelled. Regular services continue as normal.",
      severity: "critical",
      isActive: true,
      createdAt: new Date(Date.now() - 15 * 60000), // 15 minutes ago
      expiresAt: new Date(Date.now() + 2 * 60 * 60000), // expires in 2 hours
    };

    this.alerts.set(alert1.id, alert1);
    this.alerts.set(alert2.id, alert2);
    this.alerts.set(alert3.id, alert3);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      location: insertUser.location || null,
      favoriteStops: insertUser.favoriteStops || [],
      favoriteRoutes: insertUser.favoriteRoutes || [],
      notifications: insertUser.notifications ?? true,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserFavorites(userId: number, favoriteStops: string[], favoriteRoutes: string[]): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (user) {
      user.favoriteStops = favoriteStops;
      user.favoriteRoutes = favoriteRoutes;
      this.users.set(userId, user);
      return user;
    }
    return undefined;
  }

  async getAllStops(): Promise<TransportStop[]> {
    return Array.from(this.stops.values()).filter(stop => stop.isActive);
  }

  async getStop(stopId: string): Promise<TransportStop | undefined> {
    return this.stops.get(stopId);
  }

  async getNearbyStops(latitude: number, longitude: number, radiusKm: number): Promise<TransportStop[]> {
    const stops = Array.from(this.stops.values()).filter(stop => stop.isActive);
    return stops.filter(stop => {
      const distance = this.calculateDistance(latitude, longitude, stop.latitude, stop.longitude);
      return distance <= radiusKm;
    }).sort((a, b) => {
      const distanceA = this.calculateDistance(latitude, longitude, a.latitude, a.longitude);
      const distanceB = this.calculateDistance(latitude, longitude, b.latitude, b.longitude);
      return distanceA - distanceB;
    });
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  private deg2rad(deg: number): number {
    return deg * (Math.PI/180);
  }

  async createStop(insertStop: InsertTransportStop): Promise<TransportStop> {
    const id = this.currentStopId++;
    const stop: TransportStop = { 
      ...insertStop, 
      id,
      routes: insertStop.routes || [],
      isActive: insertStop.isActive ?? true
    };
    this.stops.set(stop.stopId, stop);
    return stop;
  }

  async getAllRoutes(): Promise<TransportRoute[]> {
    return Array.from(this.routes.values()).filter(route => route.isActive);
  }

  async getRoute(routeId: string): Promise<TransportRoute | undefined> {
    return this.routes.get(routeId);
  }

  async createRoute(insertRoute: InsertTransportRoute): Promise<TransportRoute> {
    const id = this.currentRouteId++;
    const route: TransportRoute = { 
      ...insertRoute, 
      id,
      color: insertRoute.color || "#2196F3",
      isActive: insertRoute.isActive ?? true
    };
    this.routes.set(route.routeId, route);
    return route;
  }

  async getLiveTransport(): Promise<LiveTransport[]> {
    return Array.from(this.liveTransports.values());
  }

  async getLiveTransportByRoute(routeId: string): Promise<LiveTransport[]> {
    return Array.from(this.liveTransports.values()).filter(transport => transport.routeId === routeId);
  }

  async getLiveTransportByStop(stopId: string): Promise<LiveTransport[]> {
    return Array.from(this.liveTransports.values()).filter(transport => transport.stopId === stopId);
  }

  async updateLiveTransport(insertTransport: InsertLiveTransport): Promise<LiveTransport> {
    const existing = this.liveTransports.get(insertTransport.vehicleId);
    const transport: LiveTransport = {
      id: existing?.id || this.currentLiveId++,
      ...insertTransport,
      speed: insertTransport.speed || null,
      heading: insertTransport.heading || null,
      stopId: insertTransport.stopId || null,
      occupancyLevel: insertTransport.occupancyLevel || 0,
      estimatedArrival: insertTransport.estimatedArrival || null,
      delay: insertTransport.delay || 0,
      lastUpdated: new Date(),
    };
    this.liveTransports.set(transport.vehicleId, transport);
    return transport;
  }

  async createTripPlan(insertTripPlan: InsertTripPlan): Promise<TripPlan> {
    const id = this.currentTripId++;
    const tripPlan: TripPlan = { 
      ...insertTripPlan, 
      id,
      routes: insertTripPlan.routes || null,
      estimatedDuration: insertTripPlan.estimatedDuration || null,
      userId: insertTripPlan.userId || null,
      createdAt: new Date() 
    };
    this.tripPlans.set(id, tripPlan);
    return tripPlan;
  }

  async getUserTripPlans(userId: number): Promise<TripPlan[]> {
    return Array.from(this.tripPlans.values()).filter(plan => plan.userId === userId);
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values()).filter(alert => 
      alert.isActive && (!alert.expiresAt || alert.expiresAt > new Date())
    );
  }

  async getAlertsByRoute(routeId: string): Promise<Alert[]> {
    return Array.from(this.alerts.values()).filter(alert => 
      alert.routeId === routeId && alert.isActive && (!alert.expiresAt || alert.expiresAt > new Date())
    );
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = this.currentAlertId++;
    const alert: Alert = { 
      ...insertAlert, 
      id,
      routeId: insertAlert.routeId || null,
      stopId: insertAlert.stopId || null,
      isActive: insertAlert.isActive ?? true,
      expiresAt: insertAlert.expiresAt || null,
      createdAt: new Date() 
    };
    this.alerts.set(id, alert);
    return alert;
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserFavorites(userId: number, favoriteStops: string[], favoriteRoutes: string[]): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ favoriteStops, favoriteRoutes })
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  async getAllStops(): Promise<TransportStop[]> {
    return await db.select().from(transportStops).where(eq(transportStops.isActive, true));
  }

  async getStop(stopId: string): Promise<TransportStop | undefined> {
    const [stop] = await db.select().from(transportStops).where(eq(transportStops.stopId, stopId));
    return stop || undefined;
  }

  async getNearbyStops(latitude: number, longitude: number, radiusKm: number): Promise<TransportStop[]> {
    const stops = await db.select().from(transportStops).where(eq(transportStops.isActive, true));
    return stops.filter(stop => {
      const distance = this.calculateDistance(latitude, longitude, stop.latitude, stop.longitude);
      return distance <= radiusKm;
    }).sort((a, b) => {
      const distanceA = this.calculateDistance(latitude, longitude, a.latitude, a.longitude);
      const distanceB = this.calculateDistance(latitude, longitude, b.latitude, b.longitude);
      return distanceA - distanceB;
    });
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  private deg2rad(deg: number): number {
    return deg * (Math.PI/180);
  }

  async createStop(insertStop: InsertTransportStop): Promise<TransportStop> {
    const [stop] = await db
      .insert(transportStops)
      .values(insertStop)
      .returning();
    return stop;
  }

  async getAllRoutes(): Promise<TransportRoute[]> {
    return await db.select().from(transportRoutes).where(eq(transportRoutes.isActive, true));
  }

  async getRoute(routeId: string): Promise<TransportRoute | undefined> {
    const [route] = await db.select().from(transportRoutes).where(eq(transportRoutes.routeId, routeId));
    return route || undefined;
  }

  async createRoute(insertRoute: InsertTransportRoute): Promise<TransportRoute> {
    const [route] = await db
      .insert(transportRoutes)
      .values(insertRoute)
      .returning();
    return route;
  }

  async getLiveTransport(): Promise<LiveTransport[]> {
    return await db.select().from(liveTransport);
  }

  async getLiveTransportByRoute(routeId: string): Promise<LiveTransport[]> {
    return await db.select().from(liveTransport).where(eq(liveTransport.routeId, routeId));
  }

  async getLiveTransportByStop(stopId: string): Promise<LiveTransport[]> {
    return await db.select().from(liveTransport).where(eq(liveTransport.stopId, stopId));
  }

  async updateLiveTransport(insertTransport: InsertLiveTransport): Promise<LiveTransport> {
    const [transport] = await db
      .insert(liveTransport)
      .values(insertTransport)
      .onConflictDoUpdate({
        target: liveTransport.vehicleId,
        set: {
          ...insertTransport,
          lastUpdated: new Date(),
        },
      })
      .returning();
    return transport;
  }

  async createTripPlan(insertTripPlan: InsertTripPlan): Promise<TripPlan> {
    const [trip] = await db
      .insert(tripPlans)
      .values(insertTripPlan)
      .returning();
    return trip;
  }

  async getUserTripPlans(userId: number): Promise<TripPlan[]> {
    return await db.select().from(tripPlans).where(eq(tripPlans.userId, userId));
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return await db.select().from(alerts).where(eq(alerts.isActive, true));
  }

  async getAlertsByRoute(routeId: string): Promise<Alert[]> {
    return await db.select().from(alerts).where(and(eq(alerts.routeId, routeId), eq(alerts.isActive, true)));
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const [alert] = await db
      .insert(alerts)
      .values(insertAlert)
      .returning();
    return alert;
  }
}

export const storage = new DatabaseStorage();
