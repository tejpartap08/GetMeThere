import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertTripPlanSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // API Routes
  app.get("/api/stops", async (req, res) => {
    try {
      const stops = await storage.getAllStops();
      res.json(stops);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stops" });
    }
  });

  app.get("/api/stops/nearby", async (req, res) => {
    try {
      const { latitude, longitude, radius = 5 } = req.query;
      
      if (!latitude || !longitude) {
        return res.status(400).json({ error: "Latitude and longitude are required" });
      }

      const lat = parseFloat(latitude as string);
      const lng = parseFloat(longitude as string);
      const radiusKm = parseFloat(radius as string);

      const stops = await storage.getNearbyStops(lat, lng, radiusKm);
      res.json(stops);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch nearby stops" });
    }
  });

  app.get("/api/routes", async (req, res) => {
    try {
      const routes = await storage.getAllRoutes();
      res.json(routes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch routes" });
    }
  });

  app.get("/api/live-transport", async (req, res) => {
    try {
      const liveTransport = await storage.getLiveTransport();
      res.json(liveTransport);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch live transport data" });
    }
  });

  app.get("/api/live-transport/route/:routeId", async (req, res) => {
    try {
      const { routeId } = req.params;
      const liveTransport = await storage.getLiveTransportByRoute(routeId);
      res.json(liveTransport);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch live transport data for route" });
    }
  });

  app.get("/api/live-transport/stop/:stopId", async (req, res) => {
    try {
      const { stopId } = req.params;
      const liveTransport = await storage.getLiveTransportByStop(stopId);
      res.json(liveTransport);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch live transport data for stop" });
    }
  });

  app.post("/api/trip-plans", async (req, res) => {
    try {
      const validatedData = insertTripPlanSchema.parse(req.body);
      const tripPlan = await storage.createTripPlan(validatedData);
      res.json(tripPlan);
    } catch (error) {
      res.status(400).json({ error: "Invalid trip plan data" });
    }
  });

  app.get("/api/alerts", async (req, res) => {
    try {
      const alerts = await storage.getActiveAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store connected clients
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('New WebSocket client connected');

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'subscribe') {
          // Handle subscription to specific routes or stops
          ws.send(JSON.stringify({
            type: 'subscription_confirmed',
            data: data.payload
          }));
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
      console.log('WebSocket client disconnected');
    });

    // Send initial data
    ws.send(JSON.stringify({
      type: 'initial_data',
      data: {
        message: 'Connected to GetMeThere real-time updates'
      }
    }));
  });

  // Function to broadcast live transport updates
  const broadcastLiveUpdates = async () => {
    if (clients.size === 0) return;

    try {
      const liveTransport = await storage.getLiveTransport();
      const message = JSON.stringify({
        type: 'live_transport_update',
        data: liveTransport,
        timestamp: new Date().toISOString()
      });

      clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(message);
        }
      });
    } catch (error) {
      console.error('Error broadcasting live updates:', error);
    }
  };

  // Simulate real-time updates every 5-10 seconds
  setInterval(async () => {
    // Update sample transport data to simulate movement
    const liveTransports = await storage.getLiveTransport();
    
    for (const transport of liveTransports) {
      // Simulate bus movement and arrival time updates
      const newLatitude = transport.latitude + (Math.random() - 0.5) * 0.001;
      const newLongitude = transport.longitude + (Math.random() - 0.5) * 0.001;
      const estimatedArrival = transport.estimatedArrival ? 
        new Date(transport.estimatedArrival.getTime() - 60000) : // Decrease by 1 minute
        new Date(Date.now() + Math.random() * 20 * 60000); // Random time up to 20 minutes

      await storage.updateLiveTransport({
        vehicleId: transport.vehicleId,
        routeId: transport.routeId,
        stopId: transport.stopId,
        latitude: newLatitude,
        longitude: newLongitude,
        heading: transport.heading,
        speed: (transport.speed || 0) + (Math.random() - 0.5) * 10,
        occupancyLevel: Math.round(Math.max(0, Math.min(100, (transport.occupancyLevel || 0) + (Math.random() - 0.5) * 20))),
        estimatedArrival,
        delay: transport.delay,
      });
    }

    broadcastLiveUpdates();
  }, 7000); // Update every 7 seconds

  return httpServer;
}
