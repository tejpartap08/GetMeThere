import { db } from "./db";
import { transportStops, transportRoutes, liveTransport, alerts } from "@shared/schema";

async function seedDatabase() {
  try {
    console.log("Starting database seeding...");

    // Create sample stops
    await db.insert(transportStops).values([
      {
        stopId: "QH_STATION",
        name: "Quakers Hill Station",
        location: "Quakers Hill, NSW",
        latitude: -33.7275,
        longitude: 150.9079,
        routes: ["632", "745"],
        isActive: true,
      },
      {
        stopId: "DOUGLAS_RD",
        name: "Douglas Road",
        location: "Quakers Hill, NSW",
        latitude: -33.7285,
        longitude: 150.9069,
        routes: ["623"],
        isActive: true,
      }
    ]).onConflictDoNothing();

    // Create sample routes
    await db.insert(transportRoutes).values([
      {
        routeId: "632",
        routeNumber: "632",
        name: "Blacktown",
        destination: "Blacktown via Quakers Hill",
        color: "#2196F3",
        isActive: true,
      },
      {
        routeId: "745",
        routeNumber: "745",
        name: "Castle Hill",
        destination: "Castle Hill Express",
        color: "#009688",
        isActive: true,
      },
      {
        routeId: "623",
        routeNumber: "623",
        name: "Parramatta",
        destination: "Parramatta via Blacktown",
        color: "#FF9800",
        isActive: true,
      }
    ]).onConflictDoNothing();

    // Create sample live transport data
    await db.insert(liveTransport).values([
      {
        vehicleId: "BUS_632_001",
        routeId: "632",
        stopId: "QH_STATION",
        latitude: -33.7270,
        longitude: 150.9075,
        heading: 45,
        speed: 25,
        occupancyLevel: 60,
        estimatedArrival: new Date(Date.now() + 8 * 60000), // 8 minutes from now
        delay: 0,
        lastUpdated: new Date(),
      },
      {
        vehicleId: "BUS_745_001",
        routeId: "745",
        stopId: "QH_STATION",
        latitude: -33.7280,
        longitude: 150.9085,
        heading: 90,
        speed: 30,
        occupancyLevel: 30,
        estimatedArrival: new Date(Date.now() + 12 * 60000), // 12 minutes from now
        delay: 0,
        lastUpdated: new Date(),
      },
      {
        vehicleId: "BUS_623_001",
        routeId: "623",
        stopId: "DOUGLAS_RD",
        latitude: -33.7290,
        longitude: 150.9065,
        heading: 180,
        speed: 15,
        occupancyLevel: 85,
        estimatedArrival: new Date(Date.now() + 5 * 60000), // 5 minutes from now but delayed
        delay: 3,
        lastUpdated: new Date(),
      }
    ]).onConflictDoUpdate({
      target: liveTransport.vehicleId,
      set: {
        latitude: -33.7270,
        longitude: 150.9075,
        lastUpdated: new Date(),
      }
    });

    // Create sample alerts
    await db.insert(alerts).values([
      {
        routeId: "632",
        stopId: null,
        title: "Service Delay",
        message: "Route 632 buses are running 5-10 minutes late due to heavy traffic on Douglas Road.",
        severity: "warning",
        isActive: true,
        createdAt: new Date(Date.now() - 30 * 60000), // 30 minutes ago
        expiresAt: new Date(Date.now() + 60 * 60000), // expires in 1 hour
      },
      {
        routeId: null,
        stopId: "QH_STATION",
        title: "Stop Maintenance",
        message: "Quakers Hill Station bus stop will have reduced accessibility due to maintenance work this afternoon.",
        severity: "info",
        isActive: true,
        createdAt: new Date(Date.now() - 60 * 60000), // 1 hour ago
        expiresAt: new Date(Date.now() + 4 * 60 * 60000), // expires in 4 hours
      },
      {
        routeId: "745",
        stopId: null,
        title: "Express Service Cancelled",
        message: "Due to mechanical issues, the next two Express 745 services have been cancelled. Regular services continue as normal.",
        severity: "critical",
        isActive: true,
        createdAt: new Date(Date.now() - 15 * 60000), // 15 minutes ago
        expiresAt: new Date(Date.now() + 2 * 60 * 60000), // expires in 2 hours
      }
    ]).onConflictDoNothing();

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

// Run seed function if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}

export { seedDatabase };